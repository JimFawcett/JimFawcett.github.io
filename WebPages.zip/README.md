# JimFawcett.github.io

Documentation for Repositories published at https://JimFawcett.github.io

<strong>Goals:</strong>
Port many of the code samples and components from https://ecs.syr.edu/faculty/fawcett.  Some of them will
get new tests and added functionality.  There will also be new code projects that I develop after retiring
from Syracuse University, and there will be more focus on Linux code as well as Windows.

<strong>Status:</strong>
I've just started this website.  Many of the links do not work yet, and there are many pages to add.
Progress will be slow over the summer due to vacation plans, but by late August 2019 the pace will pick up.
